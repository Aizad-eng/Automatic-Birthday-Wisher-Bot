import datetime as dt
import smtplib
import pandas as pd
import random

my_email = "YOUR_EMAIL"
password = "YOUR_PASSWORD"
month = dt.datetime.now().month
day = dt.datetime.now().day

letters = ["letter_1","letter_2","letter_3"]
random_file =  random.choice(letters)
data = pd.read_csv("birthdays.csv")

for i in range(len(data)):
    if data.month[i]==month and data.day[i] == day:
        birthday_person_name  = data.name[i]
        birthday_person_email = data.email[i]

        try:
            with open(f"{random_file}.txt") as file:
                letter_content = file.readlines()
        except FileNotFoundError:
            print(f"There is no file named {random_file}")
            break
        updated_letter= ""

        for line in letter_content:
            updated_line = line.replace("[name]", birthday_person_name)
            updated_letter+=updated_line

    with smtplib.SMTP("smtp.gmail.com") as connection:
        connection.starttls()
        connection.login(user=my_email , password=password)
        connection.sendmail(from_addr=my_email, to_addrs=birthday_person_email,  msg = f"Subject: Birthday {birthday_person_name}\n\n {updated_letter}")

